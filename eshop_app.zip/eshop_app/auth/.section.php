<?
$sSectionName = "Авторизация";
$arDirProperties = Array(

);
?>