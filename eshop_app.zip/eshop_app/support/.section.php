<?
$sSectionName = "Техподдержка";
$arDirProperties = Array(

);
?>