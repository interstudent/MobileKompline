<?
$sSectionName = "Персональный раздел";
$arDirProperties = Array(

);
?>