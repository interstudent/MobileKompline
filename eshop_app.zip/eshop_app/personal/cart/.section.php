<?
$sSectionName = "Корзина";
$arDirProperties = Array(

);
?>