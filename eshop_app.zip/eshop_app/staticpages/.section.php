<?
$sSectionName = "Статичные страницы";
$arDirProperties = Array(
   "description" => "Статичные страницы",
   "keywords" => "Статичные страницы",
   "title" => "Статичные страницы",
   "keywords_inner" => "Статичные страницы"
);
?>