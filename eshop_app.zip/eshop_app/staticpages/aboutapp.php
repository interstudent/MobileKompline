<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/header.php");
$APPLICATION->SetTitle("О приложении");
?>


<h1>О приложении</h1>


    <div class="static_txt">
        <ul>
            <li>Приложение интернет магазина &laquo;KompLine&raquo;</li>
            <li>Сборка: __ октября 2019</li>
            <li>Версия: 1.0</li>
            <li>Разработка: <a href="https://portal-lg.ru/">Rudnev Roman</a></li>
        </ul>
        <p>
            Работает: на 1С-Битрикс: Мобильное приложение 3.0.
        </p>
    </div>


<?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/footer.php");?>