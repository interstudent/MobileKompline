<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/header.php");
$APPLICATION->SetPageProperty("title", "Адреса магазинов");
$APPLICATION->SetTitle("Адреса магазинов");
?><h1>Адреса магазинов</h1>
<h3>Магазин № 1 "КОМПЛАЙН"</h3>
<div class="static_txt">
	<table>
	<tbody>
	<tr>
		<td>
 <b>Телефон:</b>&nbsp;
		</td>
		<td>
			 &nbsp; +38 (0642) 34 61 02
		</td>
	</tr>
	<tr>
		<td>
		</td>
		<td>
			 &nbsp; +38 (095) 702 55 51
		</td>
	</tr>
	<tr>
		<td>
		</td>
		<td>
			 &nbsp; +38 (072) 115 79 98
		</td>
	</tr>
	</tbody>
	</table>
 <br>
 <b>Адрес:</b>&nbsp;г. Луганск, пос. Юбилейный, кв. Ворошилова, д. 3
	<p>
	</p>
	 <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2640.6177028070333!2d39.190249365360415!3d48.55971692925939!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x411fdb9945c672e5%3A0xc7d54b5a7c0a88c!2z0LrQstCw0YDRgtCw0Lsg0JLQvtGA0L7RiNC40LvQvtCy0LAsIDMsINCu0LLRltC70LXQudC90LUsINCb0YPQs9Cw0L3RgdGM0LrQsCDQvtCx0LvQsNGB0YLRjCwg0KPQutGA0LDQuNC90LA!5e0!3m2!1sru!2s!4v1480443212438" width="375" height="300" frameborder="0" style="border:0" allowfullscreen></iframe><br>
 <small><a href="https://www.google.com/maps/place/%D0%BA%D0%B2%D0%B0%D1%80%D1%82%D0%B0%D0%BB+%D0%92%D0%BE%D1%80%D0%BE%D1%88%D0%B8%D0%BB%D0%BE%D0%B2%D0%B0,+3,+%D0%AE%D0%B2%D1%96%D0%BB%D0%B5%D0%B9%D0%BD%D0%B5,+%D0%9B%D1%83%D0%B3%D0%B0%D0%BD%D1%81%D1%8C%D0%BA%D0%B0+%D0%BE%D0%B1%D0%BB%D0%B0%D1%81%D1%82%D1%8C,+%D0%A3%D0%BA%D1%80%D0%B0%D0%B8%D0%BD%D0%B0/@48.5597169,39.1902494,17z/data=!4m5!3m4!1s0x411fdb9945c672e5:0xc7d54b5a7c0a88c!8m2!3d48.5598125!4d39.1926428?hl=ru">Просмотреть увеличенную карту</a></small>
</div>
<h3>Магазин № 2 "КОМПЛАЙН"</h3>
<div class="static_txt">
	<table>
	<tbody>
	<tr>
		<td>
 <b>Телефон:</b>&nbsp;
		</td>
		<td>
			 &nbsp; +38 (0642) 65 65 64
		</td>
	</tr>
	<tr>
		<td>
		</td>
		<td>
			 &nbsp; +38 (050) 018 02 07
		</td>
	</tr>
	<tr>
		<td>
		</td>
		<td>
			 &nbsp; +38 (072) 115 79 97
		</td>
	</tr>
	</tbody>
	</table>
 <br>
 <b>Адрес:</b>&nbsp;г. Луганск, ул. Советская, д. 6
	<p>
	</p>
	 <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d660.1256349339453!2d39.27093182921464!3d48.56192299870371!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x411fdadcce75f8d7%3A0xc39cce5cc225c47c!2z0LLRg9C70LjRhtGPINCg0LDQtNGP0L3RgdGM0LrQsCwgNiwg0JvRg9Cz0LDQvdGB0YzQuiwg0JvRg9Cz0LDQvdGB0YzQutCwINC-0LHQu9Cw0YHRgtGMLCDQo9C60YDQsNC40L3QsA!5e0!3m2!1sru!2sus!4v1480443735062" width="375" height="300" frameborder="0" style="border:0" allowfullscreen></iframe><br>
 <small><a href="https://www.google.com/maps/place/%D0%B2%D1%83%D0%BB%D0%B8%D1%86%D1%8F+%D0%A0%D0%B0%D0%B4%D1%8F%D0%BD%D1%81%D1%8C%D0%BA%D0%B0,+6,+%D0%9B%D1%83%D0%B3%D0%B0%D0%BD%D1%81%D1%8C%D0%BA,+%D0%9B%D1%83%D0%B3%D0%B0%D0%BD%D1%81%D1%8C%D0%BA%D0%B0+%D0%BE%D0%B1%D0%BB%D0%B0%D1%81%D1%82%D1%8C,+%D0%A3%D0%BA%D1%80%D0%B0%D0%B8%D0%BD%D0%B0/@48.5616762,39.2709077,19z/data=!4m13!1m7!3m6!1s0x411fdadcce75f8d7:0xc39cce5cc225c47c!2z0LLRg9C70LjRhtGPINCg0LDQtNGP0L3RgdGM0LrQsCwgNiwg0JvRg9Cz0LDQvdGB0YzQuiwg0JvRg9Cz0LDQvdGB0YzQutCwINC-0LHQu9Cw0YHRgtGMLCDQo9C60YDQsNC40L3QsA!3b1!8m2!3d48.561923!4d39.271479!3m4!1s0x411fdadcce75f8d7:0xc39cce5cc225c47c!8m2!3d48.561923!4d39.271479?hl=ru">Просмотреть увеличенную карту</a></small><br>
</div>
<h3>Магазин № 3 "КОМПЛАЙН"</h3>
<div class="static_txt">
	<table>
	<tbody>
	<tr>
		<td>
 <b>Телефон:</b>&nbsp;
		</td>
		<td>
			 &nbsp; +38 (0642) 34 61 02
		</td>
	</tr>
	<tr>
		<td>
		</td>
		<td>
			 &nbsp; +38 (095) 702 55 51
		</td>
	</tr>
	<tr>
		<td>
		</td>
		<td>
			 &nbsp; +38 (072) 115 79 98
		</td>
	</tr>
	</tbody>
	</table>
 <b>Адрес:</b>&nbsp;г. Луганск, ул. Ленина, д.143
	<p>
	</p>
	 <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2640.239575196082!2d39.29009101516267!3d48.56696007926001!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x411fdac953e7a895%3A0x4056f80c31e66796!2z0YPQuy4g0JvQtdC90LjQvdCwLCAxNDMsINCb0YPQs9Cw0L3RgdC6LCDQm9GD0LPQsNC90YHQutCw0Y8g0L7QsdC70LDRgdGC0YwsIDkxMDAw!5e0!3m2!1sru!2sua!4v1569003354742!5m2!1sru!2sua" width="400" height="300" frameborder="0" style="border:0;" allowfullscreen=""></iframe><br>
 <small><a href="https://www.google.com/maps/place/%D0%BA%D0%B2%D0%B0%D1%80%D1%82%D0%B0%D0%BB+%D0%92%D0%BE%D1%80%D0%BE%D1%88%D0%B8%D0%BB%D0%BE%D0%B2%D0%B0,+3,+%D0%AE%D0%B2%D1%96%D0%BB%D0%B5%D0%B9%D0%BD%D0%B5,+%D0%9B%D1%83%D0%B3%D0%B0%D0%BD%D1%81%D1%8C%D0%BA%D0%B0+%D0%BE%D0%B1%D0%BB%D0%B0%D1%81%D1%82%D1%8C,+%D0%A3%D0%BA%D1%80%D0%B0%D0%B8%D0%BD%D0%B0/@48.5597169,39.1902494,17z/data=!4m5!3m4!1s0x411fdb9945c672e5:0xc7d54b5a7c0a88c!8m2!3d48.5598125!4d39.1926428?hl=ru">Просмотреть увеличенную карту</a></small>
</div>
<br><?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/footer.php");?>