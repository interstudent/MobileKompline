<?
$sSectionName = "Каталог товаров";
$arDirProperties = Array(

);
?>